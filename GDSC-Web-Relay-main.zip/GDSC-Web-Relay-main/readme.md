# GDSC IIIT Kota - Web Relay , Tech Summit'24

**Assets Repo for different levels**

### Below is the level wise task to be performed 🔥🚀 

- **Level 1:**  Newbies 😊 - [Appwrite front page clone](https://appwrite.io)  

- **Level 2:**  Bit experienced 😃 - [AirBnb front page clone](https://www.airbnb.co.in)

- **Level 3:** Tech Gurus 😎  - [Tesla front page clone](https://www.tesla.com)